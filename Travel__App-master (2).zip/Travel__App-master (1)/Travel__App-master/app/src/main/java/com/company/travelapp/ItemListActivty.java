package com.company.travelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ItemListActivty extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list_activty);
    }
}